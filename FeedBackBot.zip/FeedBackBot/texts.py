start_text = """
hello
"""

info_button = "Информация"
info_text = """
info
"""

feedback_button = "Фидбек"
feedback_request = """
отправьте сообщение для отправки в поддержку
"""