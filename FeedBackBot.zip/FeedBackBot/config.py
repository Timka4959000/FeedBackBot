token = "123456789:XXXXXXXXXXXXXXXX"
password = 1234
admins_ids = []
group_id = -100123